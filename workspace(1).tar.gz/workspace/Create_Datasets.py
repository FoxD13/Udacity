# TODO: Define your transforms for the training, validation, and testing sets
import torch
from torchvision import datasets, transforms

def Create_Datasets(data_dir):
    train_dir = data_dir + '/train'
    valid_dir = data_dir + '/valid'
    test_dir = data_dir + '/test'
    
    train_transforms = transforms.Compose([transforms.RandomResizedCrop(224),
                                           transforms.RandomRotation(30),
                                           transforms.RandomHorizontalFlip(),
                                           transforms.RandomVerticalFlip(),
                                           transforms.ToTensor(),
                                           transforms.Normalize([0.485, 0.456, 0.406],[0.229, 0.224, 0.225])])
    
    test_transforms = transforms.Compose([transforms.Resize(255),
                                          transforms.CenterCrop(224),
                                          transforms.ToTensor(),
                                          transforms.Normalize([0.485, 0.456, 0.406],[0.229, 0.224, 0.225])])
    
    # TODO: Load the datasets with ImageFolder
    image_dataset_train = datasets.ImageFolder(train_dir, transform=train_transforms)
    image_dataset_valid =  datasets.ImageFolder(valid_dir, transform=test_transforms)
    image_dataset_test =  datasets.ImageFolder(test_dir, transform=test_transforms)
    
    
    # TODO: Using the image datasets and the trainforms, define the dataloaders
    dataloader_train = torch.utils.data.DataLoader(image_dataset_train, batch_size=64, shuffle=True)
    dataloader_valid =  torch.utils.data.DataLoader(image_dataset_valid,  batch_size=64)
    dataloader_test =  torch.utils.data.DataLoader(image_dataset_test,  batch_size=64)
    
    return dataloader_train, dataloader_valid, dataloader_test, image_dataset_train.class_to_idx
