import torch
from torch import optim, nn
import torch.nn.functional as F
from torchvision import models
from collections import OrderedDict


def Create_Model(arch, hidden_units):
    
    if arch == 'vgg16':
        model = models.vgg16(pretrained=True)
        for param in model.parameters():
            param.requires_grad = False
        
    elif arch == 'vgg13':
        model = models.vgg13(pretrained=True)
        for param in model.parameters():
            param.requires_grad = False    
    else:
        print("model not available. Use \"vgg16\", oder \"vgg13\"")
        return 

    model.classifier = nn.Sequential(OrderedDict([
        ('0', nn.Linear(25088, hidden_units)),
        ('1', nn.Dropout(0.5)),
        ('2', nn.ReLU()),
        ('3', nn.Linear(hidden_units, 102)),
        ('4', nn.LogSoftmax(dim=1))
    ]))
    
    model.optimizer = optim.SGD(model.classifier.parameters(), lr=0.003)
        
    return model