"""
Predict

usage: python ImageClassifier/predict.py checkpoint.pth ImageClassifier/flowers/train/55/image_04756.jpg ImageClassifier/cat_to_name.json cpu 3

Predict flower name from an image with predict.py along with the probability of that name. That is, you'll pass in a single image /path/to/image and return the flower name and class probability.

    Basic usage: python predict.py /path/to/image checkpoint
    python ImageClassifier/predict.py ImageClassifier/flowers/train/55/image_04756.jpg checkpoint.pth
    Options:
        Return top KKK most likely classes: python predict.py input checkpoint --top_k 3
        Use a mapping of categories to real names: python predict.py input checkpoint --category_names cat_to_name.json
        Use GPU for inference: python predict.py input checkpoint --gpu
        
    reads in an image and a checkpoint then prints the most likely image class and it's associated probability
    Top K classes 	The predict.py script allows users to print out the top K classes along with associated probabilities
    Displaying class names 	The predict.py script allows users to load a JSON file that maps the class values to other category names
    Predicting with GPU 	The predict.py script allows users to use the GPU to calculate the predictions

"""

# myls.py
# Import the argparse library
import argparse
import os
import sys

import torch
from torch import optim, nn
import torch.nn.functional as F
from torchvision import models
from collections import OrderedDict

import get_input_args_predict
import Create_Datasets
import Map_Labels
import Create_Model
import Load_Checkpoint
import Process_Image
import Predict_Image

# Get parsed Arguments
args = get_input_args_predict.get_input_args()

#Load Arguments
image_path = args.image_path
checkpoint_path = args.filepath
cat_to_name = args.category_names
device = args.gpu
topk = args.top_k

#Rebuild Model
model = Load_Checkpoint.Load_Checkpoint(checkpoint_path, device)
optimizer = model.optimizer
criterion = nn.NLLLoss()
model.to(device)
model.eval()

image = Process_Image.process_image(image_path)
probs, classes = Predict_Image.predict(image, model, device, cat_to_name, topk)
categories = Map_Labels.Map_Labels(cat_to_name, model.class_to_idx, classes)
    
print("topk results: \n", categories)
print("probabilities: \n", probs)