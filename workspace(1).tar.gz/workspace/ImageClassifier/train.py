"""
1. Train

Train a new network on a data set with train.py

    Basic usage: python train.py data_directory
    python ImageClassifier/train.py ImageClassifier/flowers/
    python ImageClassifier/train.py ImageClassifier/flowers/ -e 1 -d cuda
    Prints out training loss, validation loss, and validation accuracy as the network trains
    Options:
        Set directory to save checkpoints: python train.py data_dir --save_dir save_directory
        Choose architecture: python train.py data_dir --arch "vgg13"
        Set hyperparameters: python train.py data_dir --learning_rate 0.01 --hidden_units 512 --epochs 20
        Use GPU for training: python train.py data_dir --gpu
"""

# myls.py
# Import the argparse library
import argparse
import os
import sys

import torch
from torch import optim, nn
import torch.nn.functional as F
from torchvision import models
from collections import OrderedDict
import json
import numpy as np
from PIL import Image
import math

import get_input_args_train
import Create_Datasets
import Create_Model
import Load_Checkpoint
import Train_Model


#use sysargs for dataset argument
args = get_input_args_train.get_input_args()

data_dir = args.data_dir
filepath = args.save_dir
arch = args.arch
learning_rate = args.learning_rate
hidden_units = args.hidden_units
epochs = args.epochs
device = args.gpu


#Create Datasets for Training, Validation and Testing
dataloader_train, dataloader_valid, dataloader_test, class_to_idx = Create_Datasets.Create_Datasets(data_dir)

try:
    model = Load_Checkpoint.Load_Checkpoint(filepath, device)
    optimizer = model.optimizer
    ACCepoch = model.ACCepoch
    if model.arch != arch and model.hidden_units != hidden_units:
        print("Model Architecture within selected Checkpoint file: ", model.arch)
        print("Model's Number of Hidden units within selected Checkpoint file: ", model.hidden_units)
        answer = input("You are about to erase the model saved to your checkpoint file and overwrite it with a new one. Confirm with Y(es), Abort with N(o) (Y|N)")
        if answer == 'Y':
            model = Create_Model.Create_Model(arch, hidden_units)
            optimizer = optim.SGD(model.classifier.parameters(), lr=learning_rate)
            ACCepoch = 0
        else:
            exit()
except:
    print("No Checkpoint found. Proceeding to create new model")
    model = Create_Model.Create_Model(arch, hidden_units)
    optimizer = optim.SGD(model.classifier.parameters(), lr=learning_rate)
    ACCepoch = 0
    pass

if learning_rate != 0.01:
    optimizer = optim.SGD(model.classifier.parameters(), lr=learning_rate)

model.to(device)
model.train()
model.arch = arch
model.hidden_units = hidden_units
model.class_to_idx = class_to_idx

Train_Model.Train_Model(model, optimizer, device, epochs, ACCepoch, filepath, dataloader_train, dataloader_valid)
