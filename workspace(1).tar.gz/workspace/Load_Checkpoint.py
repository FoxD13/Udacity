import torch
from torch import optim, nn
from torchvision import models
from collections import OrderedDict

import Create_Model


def Load_Checkpoint(filepath, device):
    #load the checkpoint
    print(filepath)
    if str(device) == "cpu":
        checkpoint = torch.load(filepath, map_location="cpu")
    else:
        checkpoint = torch.load(filepath)
    # Rebuild to Checkpoint
    model = Create_Model.Create_Model(checkpoint['arch'], checkpoint['hidden_units'])
    model.load_state_dict(checkpoint['model_state_dict'])
    model.optimizer.load_state_dict(checkpoint['optim_state_dict'])
    model.class_to_idx = checkpoint['class_to_idx']
    model.ACCepoch = checkpoint['ACCepoch']
    model.arch = checkpoint['arch']
    model.hidden_units = checkpoint['hidden_units']
    print("Checkpoint loaded")
    
    return model