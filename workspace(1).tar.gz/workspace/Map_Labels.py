import json

def Map_Labels(cat_to_name, class_to_idx, classes):

    categories=[]
    int_to_cat={} 
    
    with open(cat_to_name, 'r') as f:
        cat_to_name = json.load(f)
    
    labelmap= {}
    
    idx_to_class = {val: key for key, val in class_to_idx.items()}
    
    for i in range(len(class_to_idx)):
        int_to_cat[i] = cat_to_name.get(str(idx_to_class[i]))
        
    for c in classes:
        categories.append(int_to_cat[c])

    return categories