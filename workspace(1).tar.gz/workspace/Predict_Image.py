import numpy as np
import torch
from torch import optim, nn

def predict(image, model, device, labelmap, topk=5):
   
    model.eval()

    # Calculate the class probabilities (softmax) for img
    with torch.no_grad():
        image = image.to(device)
        model = model.to(device)
        output = model.forward(image)
        ps = torch.exp(output)
        
        probs, classes = ps.topk(topk,largest=True, sorted=True)
        probs = probs[0,:].to("cpu").numpy()
        classes = classes[0,:].to("cpu").numpy()

    return probs, classes