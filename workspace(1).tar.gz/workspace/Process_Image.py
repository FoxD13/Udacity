import numpy as np
from PIL import Image
import math
import torch

def process_image(image_path):
    ''' Scales, crops, and normalizes a PIL image for a PyTorch model,
        returns an Numpy array
    '''
            
    with Image.open(image_path) as image:
        #print("before resizing:\n\n", image,"\n")
        # TODO: Process a PIL image for use in a PyTorch model
        size = 256
        width = image.size[0]
        height = image.size[1]
        ratio = width / height
        mean = np.array([0.485, 0.456, 0.406])
        std = np.array([0.229, 0.224, 0.225])
        
        #resize
        if height > width:
            image.thumbnail((size,height))
        else:
            image.thumbnail((height,size))
                
        width = image.size[0]
        height = image.size[1]
        
        #crop
        image = image.crop(((width-224)/2,(height-224)/2,224+(width-224)/2,224+(height-224)/2))
        
        
        #create np array
        np_image = np.array(image)
        #normalize color channel to 0-1
        np_image = np_image / 255
        
        #normalize
        np_image = (np_image - mean) / std
        #print(np_image[112,112])
        
        #transpose colorchannel
        np_image = np_image.transpose(2,0,1)
        
            # Process image for usage with model
        torch_image = torch.from_numpy(np_image)
        torch_image = torch.unsqueeze(torch_image, 0)
        torch_image = torch_image.float()

    return torch_image