import torch
from torch import optim, nn
from torchvision import models

def Save_Checkpoint(model, optimizer, ACCepoch, filepath):
    checkpoint = {'ACCepoch': ACCepoch,
                  'model_state_dict': model.state_dict(),
                  'optim_state_dict': optimizer.state_dict(),
                  'hidden_units': model.hidden_units,
                  'arch': model.arch,
                  'class_to_idx': model.class_to_idx
                 }

    torch.save(checkpoint, filepath)
    print("Checkpoint saved")