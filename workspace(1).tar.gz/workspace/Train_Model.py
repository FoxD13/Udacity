import torch
from torch import optim, nn
import torch.nn.functional as F
from torchvision import models

import Save_Checkpoint

def Train_Model(model, optimizer, device, epochs, ACCepoch, filepath, dataloader_train, dataloader_valid):
    
    steps = 0
    print_every = 5
    running_loss = 0
    train_losses, validation_losses = [], []
    
    criterion = nn.NLLLoss()
    for epoch in range(epochs):
        for inputs, labels in dataloader_train:
            steps += 1
            # Move input and label tensors to the default device
            inputs, labels = inputs.to(device), labels.to(device)
            
            optimizer.zero_grad()
            
            logps = model.forward(inputs)
            loss = criterion(logps, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            
            if steps % print_every == 0:
                model.eval()
                validation_loss = 0
                accuracy = 0
                with torch.no_grad():
                    for inputs, labels in dataloader_valid:
                        inputs, labels = inputs.to(device), labels.to(device)
                        logps = model.forward(inputs)
                        batch_loss = criterion(logps, labels)
                        validation_loss += batch_loss.item()
                    
                        # Calculate accuracy
                        ps = torch.exp(logps)
                        top_p, top_class = ps.topk(1, dim=1)
                        equals = top_class == labels.view(*top_class.shape)
                        accuracy += torch.mean(equals.type(torch.FloatTensor)).item()
                    
                        validation_losses.append(validation_loss/len(dataloader_valid))
                        train_losses.append(running_loss/len(dataloader_train))
                                            
                print(f"Epoch {epoch+1}/{epochs}.. "
                      f"Train loss: {running_loss/print_every:.3f}.. "
                      f"Validation loss: {validation_loss/len(dataloader_valid):.3f}.. "
                      f"Validation accuracy: {accuracy/len(dataloader_valid):.3f}")

                running_loss = 0
                model.train()
        ACCepoch +=1
        Save_Checkpoint.Save_Checkpoint(model, optimizer, ACCepoch, filepath)