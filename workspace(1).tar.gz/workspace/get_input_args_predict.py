import argparse
 
def get_input_args():
    
    Parse = argparse.ArgumentParser(description="Processing Data with CNNs")
    
    Parse.add_argument('image_path', type=str, help='path to the image for prediction')
    Parse.add_argument('filepath', type=str, help='path to the checkpoint file')
    Parse.add_argument('-c', '--category_names', default = "ImageClassifier/cat_to_name.json", type=str, help='file mapping folders to labels', required = False)
    Parse.add_argument('-d', '--gpu', default = "cpu", type=str, help='device used for prediction', required = False)
    Parse.add_argument('-t' ,'--top_k', default = 3, type=int, help='number of possible results after prediction', required = False)
    
    return Parse.parse_args()