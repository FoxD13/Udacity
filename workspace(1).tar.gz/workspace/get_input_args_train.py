import argparse

def get_input_args():

    Parse = argparse.ArgumentParser(description="Processing Data with CNNs")

    Parse.add_argument('data_dir', metavar='data_dir', type=str, help='Set directory to datasetfolders')
    Parse.add_argument('-save', '--save_dir', default = 'checkpoint2.pth', type=str, help='Set directory to save checkpoints', required = False)
    Parse.add_argument('--arch', default = 'vgg13', type=str, help='Choose architecture', required = False)
    Parse.add_argument('-lr','--learning_rate', default = 0.01, type=float, help='Set hyperparameter learning_rate', required = False)
    Parse.add_argument('-hu','--hidden_units', default = 512, type=int, help='Set hyperparameter hidden_units', required = False)
    Parse.add_argument('-e','--epochs', default = 20, type=int, help='Set hyperparameter epochs', required = False)
    Parse.add_argument('-d', '--gpu', default = 'cpu', type=str, help='Use GPU for training', required = False)

    return Parse.parse_args()